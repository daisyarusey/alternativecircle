<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="icon" type="image/png" sizes="96x96" href="images/favicon.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Alternative Circle</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />

	    

     <!-- Bootstrap core CSS     -->
    <link href="css/bootstrap.min.css" rel="stylesheet" />

    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700,900" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="fa/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="css/aos.css">


    
    <link href="style.css" rel="stylesheet" />
</head>

<body>
    <div class="home-section">
    	<div class="container">
    		<div class="row">
    			<div class="col-sm-12">
    				<div class="logo-wrapper">
    					<a href=""><img src="images/logo.png" ></a>
    				</div>
    			</div>
    		</div>
    		<div class="row">
    			<div class="col-sm-12">
    				<div class="home-banner-copy" data-aos="fade-up">
    					<!-- <p>On a mission to provide financial access through technology to over 200 million people globally</p> -->
    					<p>On a mission<br>
to provide financial access<br>
through technology to<br>
over 200 million people<br> 
globally</p>
    				</div>
    				
    			</div>
    		</div>
    		
    	</div>
    </div>


    <section class="section founders">
    	<div class="container">
    		<div class="row">
    			<div class="col-sm-12">
    				<h3 class="section-title text-center" data-aos="fade-up">Our Founders</h3>
    			</div>

    			<!-- the founders image column -->
    			<div class="col-sm-5 text-center">
    				<div class="founder-profile" data-aos="fade-up">
    					<div class="profile-pic">
    					<img src="images/kevin.png" />
    				</div>

    				<h3>Kevin Mutiso</h3>
    				<h4><i>Chief Executive Officer</i></h4>
    				</div>




    				<div class="founder-profile" data-aos="fade-up">
    					<div class="profile-pic">
    					<img src="images/anthony.png" />
    				</div>

    				<h3>Anthony Kariuki</h3>
    				<h4><i>Chief Experience Officer</i></h4>
    				</div>
    				
    			</div>




    			<!-- founders narrative column -->

    			<div class="col-sm-7">
    				<div class="founders-narrative" data-aos="fade-up">
    					<p>Kevin Mutiso and Anthony Kariuki founded Alternative Circle in 2016 with a mission to provide financial access to users through technology . Alternative Circle closed a seed round of $1.1 million from CreditInfo to scale the company.</p>
    				<p>The strategic partnership with CreditInfo also gave Alternative Circle access to over 200 developers and 25 data scientists, making it easier for Alternative Circle to become the leading Financial Technology Innovator in the country. Currently, Alternative Circle has raised over $10 million from banks for the lending pool, with other institutions also in the waiting list to join the pool.</p>
    				</div>
    				
    			</div>


    		</div>
    	</div>
    </section>



    <section class="section product">
    	<div class="container">
    		<div class="row">
    			<div class="col-sm-12">
    				<h3 class="section-title text-center" data-aos="fade-up">Our Product</h3>
    			</div>

    			<div class="col-sm-12">
    				<div class="product-logo mobile-product-logo" data-aos="fade-up">
						<img src="images/shika_logo.png">
					</div>
    			</div>

    			<div class="col-sm-5 text-center">
    				<div class="product-image" data-aos="fade-up">
    					<img src="images/phone.png" />
    				</div>
    			</div>


    			<div class="col-sm-7">
    				<div class="product-narrative" data-aos="fade-up">
    					<div class="product-logo lg-product-logo">
							<img src="images/shika_logo.png">
						</div>			
    					<p>Shika is our first step to achieve our mission. Shika is a mobile microlending platform that provides an easy, fast and efficient way to lend to individuals with no loan history.</p>
    				<p>Shika performs background checks (Know Your Customer) and approves users in less than 180 seconds. Shika is built with financial institutions in mind.  These institutions need new channels to disburse micro-loans since they have no human capital or the infrastructure to give out microloans.</p>
    				<p>Alternative Circle has partnered with banks, filling in that gap by letting its customers without a credit history access loans in a fast and easy way. Our preview release which is available for Android phones only can be downloaded from  Google Playstore.</p>
    				</div>
    				
    			</div>
    		</div>
    	</div>
    </section>


    <section class="section featured">
    	<div class="container">
    		<div class="row">
    			<div class="col-sm-12">
    				<h3 class="section-title text-center" data-aos="fade-up">Alternative Circle As Reported</h3>
    			</div>
    		</div>

    		<div class="row media-logos text-center">
    			<div class="col-sm-3">
    			<a href="" target="_blank" data-aos="fade-up">
    				<img src="images/disrupt_logo.png" class="img-responsive">
    			</a>
    			</div>

    			<div class="col-sm-3">
    			<a href="" target="_blank" data-aos="fade-up">
    				<img src="images/techweez_logo.png" class="img-responsive mt-15">
    			</a>
    			</div>

    			<div class="col-sm-3">
    			<a href="" target="_blank" data-aos="fade-up">
    				<img src="images/ventureburn_logo.png" class="img-responsive mt-15">
    			</a>
    			</div>

    			<div class="col-sm-3">
    			<a href="" target="_blank" data-aos="fade-up">
    				<img src="images/techmoran-logo.png" class="img-responsive">
    			</a>
    			</div>
    		</div>
    	</div>
    </section>

    <section class="section ac-footer">
    	<div class="container">
    		<div class="footer-content text-center">
    			<p class="social-links">
    				<a href="https://www.facebook.com/Shikaapp" target="_blank"><i class="fa fa-facebook-square"></i></a>
    				<a href="https://twitter.com/Shika_app" target="_blank"><i class="fa fa-twitter-square"></i></a>
    				<a href="https://www.instagram.com/shika_app/" target="_blank"><i class="fa fa-linkedin-square"></i></a>
    			</p>
    			<p class="ac-location">Alternative Circle <i class="fa fa-circle"></i> 4th Floor, Orbit Place <i class="fa fa-circle"></i> Westlands-Nairobi</p>
    			<p><strong>&copy; Alternative Circle</strong></p>
    		</div>
    	</div>
    </section>
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/aos.js"></script>
    <script type="text/javascript">
    	$(function(){
    		AOS.init();
    	});
    </script>
</body>
</html>